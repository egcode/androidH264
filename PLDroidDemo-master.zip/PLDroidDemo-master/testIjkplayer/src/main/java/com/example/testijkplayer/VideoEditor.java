package com.example.testijkplayer;

import tv.danmaku.ijk.media.player.IjkMediaPlayer;

public class VideoEditor extends IjkMediaPlayer{

	public VideoEditor() {
		// TODO Auto-generated constructor stub
	}
	
}
