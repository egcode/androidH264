package com.dudu.drivevideo.event;

/**
 * Created by dengjun on 2016/2/19.
 * Description :
 */
public class FrontCameraReadyPreview {
}
