package com.dudu.drivevideo.config;

/**
 * Created by dengjun on 2016/2/18.
 * Description :
 */
public class DriveVideoContants {
    public static final String REAR_VIDEO_STORAGE_PARENT_PATH = "/dudu";
    public static final String FRONT_VIDEO_STORAGE_PATH = "/frontVideo";
    public static final String REAR_VIDEO_STORAGE_PATH = "/rearVideo";

    public static final String FRONT_PICTURE_STORAGE_PATH = "/frontPicture";
}
