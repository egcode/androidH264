package com.dudu.drivevideo.model;

import android.net.Uri;

/**
 * Created by dengjun on 2016/2/21.
 * Description :
 */
public class PhotoInfoEntity {
    private Uri photoInfoUri;

    public Uri getPhotoInfoUri() {
        return photoInfoUri;
    }

    public void setPhotoInfoUri(Uri photoInfoUri) {
        this.photoInfoUri = photoInfoUri;
    }
}
