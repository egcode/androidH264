package org.wysaid.nativePort;

/**
 * Created by wangyang on 15/7/30.
 */
public class FFmpegNativeLibrary {
    static {
        NativeLibraryLoader.load();
    }


    //////////////////////////////////////////
//    public static native void avRegisterAll();

}
