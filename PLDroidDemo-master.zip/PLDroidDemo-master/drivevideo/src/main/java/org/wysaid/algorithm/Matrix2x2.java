package org.wysaid.algorithm;

/**
 * Created by wangyang on 15/11/27.
 */
public class Matrix2x2 {
}
