package com.angcyo.pldroiddemo;

/**
 * Created by jerikc on 16/2/5.
 */
public interface Rotatable {
    // Set parameter 'animation' to true to have animation when rotation.
    void setOrientation(int orientation, boolean animation);
}
