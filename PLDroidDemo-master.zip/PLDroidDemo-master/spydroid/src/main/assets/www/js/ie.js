document.createElement('header');
document.createElement('nav');
document.createElement('section');
document.createElement('article');
document.createElement('aside');
document.createElement('footer');
document.createElement('hgroup');

$(document).ready(function () {
    $('.section-content,#status-container').addClass('ie8-background');
    $('.category-separator').hide();
});