package com.github.libffmpeg.exceptions;

public class FFmpegNotSupportedException extends Exception {

    public FFmpegNotSupportedException(String message) {
        super(message);
    }

}
