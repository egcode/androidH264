package com.github.libffmpeg;

/**
 */
public class FFmpegSyncResponseHandler implements FFmpegSyncResponseInterface {
    @Override
    public void onSuccess(String message) {

    }

    @Override
    public void onProgress(int percent) {

    }

    @Override
    public void onMetadata(Metadata metadata) {

    }

    @Override
    public void onFailure(String message) {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onFinish(boolean success, boolean isCancelled) {

    }
}
